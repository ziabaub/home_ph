<?php
/**
 * Created by PhpStorm.
 * User: ziadelsarrih
 * Date: 2019-05-14
 * Time: 10:38
 */

define('table_user_info', 'user_info');
define('table_current_users', 'current_users');
define('database', 'user_employee');
//define('host', '127.0.0.1');
//define('user', 'root');
//define('pass', 'Mays0un');
define('host','148.66.138.127');
define('user','qannese9yefn');
define('pass','@Msrtraiding66');
define('fields', 'name,address,phone,email,permission');
